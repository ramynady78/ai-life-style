import { Response } from "express";
import { pool } from "../config/db";
import { AuthedRequest } from "../middleware/auth.middleware";

type RecommendationContent = {
  workout_plan: string;
  daily_routine: string;
  calorie_target: number;
};

function buildRecommendationContent(profile: Record<string, any>): RecommendationContent {
  const goalType = profile.goal_type ?? "maintain";
  const experienceLevel = profile.experience_level ?? "beginner";
  const gymDays = Number(profile.gym_days_per_week ?? 3);
  const sessionMinutes = Number(profile.session_minutes ?? 60);
  const weight = Number(profile.initial_weight_kg ?? 70);

  const calorieTarget =
    goalType === "lose_weight"
      ? Math.max(1500, weight * 22)
      : goalType === "gain_muscle"
        ? Math.min(3500, weight * 33)
        : Math.min(3000, Math.max(1800, weight * 28));

  const workoutFocus =
    goalType === "lose_weight"
      ? "Fat-loss focused strength training with light cardio finishers"
      : goalType === "gain_muscle"
        ? "Progressive overload strength training with compound lifts"
        : "Balanced strength and conditioning to maintain fitness";

  const workoutPlan = [
    `Goal: ${goalType.replace(/_/g, " ")}`,
    `Experience: ${experienceLevel}`,
    `Weekly frequency: ${gymDays} gym day(s) per week`,
    `Session duration: about ${sessionMinutes} minutes`,
    `Focus: ${workoutFocus}`,
    "Day 1: Upper body push + core",
    "Day 2: Lower body + mobility",
    "Day 3: Upper body pull + conditioning",
    gymDays >= 4 ? "Day 4: Full body + interval cardio" : "Optional Day 4: Recovery walk + stretching",
  ].join("\n");

  const dailyRoutine = [
    `Calories: ${Math.round(calorieTarget)} kcal/day`,
    "Protein: prioritize a serving of lean protein in each main meal",
    "Hydration: 2-3 liters of water daily",
    "Sleep: target 7-8 hours per night",
    "Steps: aim for 8,000-10,000 daily steps",
    "Recovery: add 10 minutes of stretching after workouts",
  ].join("\n");

  return {
    workout_plan: workoutPlan,
    daily_routine: dailyRoutine,
    calorie_target: Math.round(calorieTarget),
  };
}

export const generatePlan = async (
  req: AuthedRequest,
  res: Response,
): Promise<void> => {
  try {
    const userId = req.user?.id;

    if (!userId) {
      res.status(401).json({ message: "Unauthorized" });
      return;
    }

    const profileResult = await pool.query(
      "SELECT * FROM user_profile WHERE user_id = $1",
      [userId],
    );

    if (profileResult.rows.length === 0) {
      res.status(404).json({ message: "Profile not found" });
      return;
    }

    const profile = profileResult.rows[0];
    const content = buildRecommendationContent(profile);

    await pool.query(
      "UPDATE recommendations SET status = 'archived' WHERE user_id = $1 AND status = 'active'",
      [userId],
    );

    const versionResult = await pool.query(
      "SELECT COALESCE(MAX(version), 0) + 1 AS next_version FROM recommendations WHERE user_id = $1",
      [userId],
    );

    const version = Number(versionResult.rows[0].next_version);

    const insertResult = await pool.query(
      `INSERT INTO recommendations (user_id, version, status, content, generated_by)
       VALUES ($1, $2, 'active', $3::jsonb, 'rule_based')
       RETURNING id, user_id, version, status, content, generated_by, created_at`,
      [userId, version, JSON.stringify(content)],
    );

    res.status(200).json({
      plan: insertResult.rows[0].content,
      version: insertResult.rows[0].version,
    });
  } catch (error) {
    console.error("Error generating recommendation plan:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

export const getActivePlan = async (
  req: AuthedRequest,
  res: Response,
): Promise<void> => {
  try {
    const userId = req.user?.id;

    if (!userId) {
      res.status(401).json({ message: "Unauthorized" });
      return;
    }

    const result = await pool.query(
      `SELECT id, user_id, version, status, content, generated_by, created_at
       FROM recommendations
       WHERE user_id = $1 AND status = 'active'
       ORDER BY created_at DESC
       LIMIT 1`,
      [userId],
    );

    if (result.rows.length === 0) {
      res.status(404).json({ message: "No active recommendation found" });
      return;
    }

    res.status(200).json(result.rows[0]);
  } catch (error) {
    console.error("Error getting active recommendation:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};
