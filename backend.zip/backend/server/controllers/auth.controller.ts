import type { Request, Response } from "express";
import bcrypt from "bcrypt";
import { pool } from "../config/db";
import { generateJwtToken } from "../middleware/generateJwtToken";

export async function register(req: Request, res: Response) {
  const { first_name, last_name,username ,email, password } = req.body as { first_name: string; last_name: string; username: string; email: string; password: string };
  if (!first_name || !last_name || !username || !email || !password) return res.status(400).json({ message: "First name, last name, username, email, and password required" });
  
  // Check if user already exists
  // Check if email already exists
  const existingEmail = await pool.query("SELECT * FROM users WHERE email=$1", [email]);
  if (existingEmail.rows.length > 0) return res.status(400).json({ message: "this email already exists" });
  // Check if username already exists
  const existingUsername = await pool.query("SELECT * FROM users WHERE username=$1", [username]);
  if (existingUsername.rows.length > 0) return res.status(400).json({ message: "this username already exists" });

  // Hash the password and store the user in the database
  const hash = await bcrypt.hash(password, 10);
  const result = await pool.query(
    "INSERT INTO users(first_name, last_name, username, email, password_hash) VALUES ($1,$2,$3,$4,$5) RETURNING id",
    [first_name, last_name, username, email, hash]
  );

  if (result.rowCount === 0) return res.status(500).json({ message: "Failed to register user" });
  const token = generateJwtToken(result.rows[0].id);
  res.status(201).json({ message: "User registered", token });
}

export async function login(req: Request, res: Response) {
  const { email, password } = req.body as { email: string; password: string };
  if (!email || !password) return res.status(400).json({ message: "email and password required" });

  const result = await pool.query("SELECT id, password_hash FROM users WHERE email=$1", [email]);
  if (result.rows.length === 0) return res.status(400).json({ message: "This email is not registered, please sign up first" });

  const ok = await bcrypt.compare(password, result.rows[0].password_hash);
  if (!ok) return res.status(400).json({ message: "Incorrect password, please try again" });

  const token = generateJwtToken(result.rows[0].id);
  res.status(200).json({ token });
}

export async function logout(_req: Request, res: Response) {
  // Since we're using JWTs, logout can be handled on the client side by simply deleting the token.
  // Optionally, you could implement token blacklisting on the server side if you want to invalidate tokens before they expire.
  res.status(200).json({ message: "Logged out" });
}

export async function getCurrentUser(req: Request, res: Response) {
  const userId = (req as any).user.id;
  const result = await pool.query("SELECT id, first_name, last_name, username, email FROM users WHERE id=$1", [userId]);
  if (result.rows.length === 0) return res.status(404).json({ message: "User not found" });
  res.status(200).json(result.rows[0]);
}
