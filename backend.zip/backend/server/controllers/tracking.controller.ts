import { Response } from "express";
import { pool } from "../config/db";
import { AuthedRequest } from "../middleware/auth.middleware";

function normalizeDate(value?: string): string {
  if (value) {
    return value;
  }

  return new Date().toISOString().slice(0, 10);
}

export const createMeasurement = async (
  req: AuthedRequest,
  res: Response,
): Promise<void> => {
  try {
    const userId = req.user?.id;

    if (!userId) {
      res.status(401).json({ message: "Unauthorized" });
      return;
    }

    const { measuredAt, weightKg, waistCm, sleepHoursAvg, stepsAvg } = req.body as {
      measuredAt?: string;
      weightKg?: number | null;
      waistCm?: number | null;
      sleepHoursAvg?: number | null;
      stepsAvg?: number | null;
    };

    const result = await pool.query(
      `INSERT INTO measurements (user_id, measured_at, weight_kg, waist_cm, sleep_hours_avg, steps_avg)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING id, user_id, measured_at, weight_kg, waist_cm, sleep_hours_avg, steps_avg, created_at`,
      [
        userId,
        normalizeDate(measuredAt),
        weightKg ?? null,
        waistCm ?? null,
        sleepHoursAvg ?? null,
        stepsAvg ?? null,
      ],
    );

    const adjustment =
      weightKg != null && weightKg > 100
        ? {
            action: "increase_intensity",
            reason: "Weight trend suggests more activity may help progress.",
          }
        : {
            action: "no_change",
            reason: "Current data does not require a plan adjustment yet.",
          };

    res.status(201).json({
      measurement: result.rows[0],
      adjustment,
    });
  } catch (error) {
    console.error("Error creating measurement:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

export const listMeasurements = async (
  req: AuthedRequest,
  res: Response,
): Promise<void> => {
  try {
    const userId = req.user?.id;

    if (!userId) {
      res.status(401).json({ message: "Unauthorized" });
      return;
    }

    const result = await pool.query(
      `SELECT id, user_id, measured_at, weight_kg, waist_cm, sleep_hours_avg, steps_avg, created_at
       FROM measurements
       WHERE user_id = $1
       ORDER BY measured_at ASC, created_at ASC`,
      [userId],
    );

    res.status(200).json(result.rows);
  } catch (error) {
    console.error("Error listing measurements:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

export const listAdherenceLogs = async (
  req: AuthedRequest,
  res: Response,
): Promise<void> => {
  try {
    const userId = req.user?.id;

    if (!userId) {
      res.status(401).json({ message: "Unauthorized" });
      return;
    }

    const result = await pool.query(
      `SELECT id, user_id, log_date, workout_done, completion_pct, comment, created_at
       FROM adherence_logs
       WHERE user_id = $1
       ORDER BY log_date ASC, created_at ASC`,
      [userId],
    );

    res.status(200).json(result.rows);
  } catch (error) {
    console.error("Error listing adherence logs:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

export const createAdherenceLog = async (
  req: AuthedRequest,
  res: Response,
): Promise<void> => {
  try {
    const userId = req.user?.id;

    if (!userId) {
      res.status(401).json({ message: "Unauthorized" });
      return;
    }

    const { logDate, workoutDone, completionPct, comment } = req.body as {
      logDate?: string;
      workoutDone?: boolean;
      completionPct?: number | null;
      comment?: string | null;
    };

    const result = await pool.query(
      `INSERT INTO adherence_logs (user_id, log_date, workout_done, completion_pct, comment)
       VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (user_id, log_date)
       DO UPDATE SET
         workout_done = EXCLUDED.workout_done,
         completion_pct = EXCLUDED.completion_pct,
         comment = EXCLUDED.comment
       RETURNING id, user_id, log_date, workout_done, completion_pct, comment, created_at`,
      [userId, normalizeDate(logDate), workoutDone ?? false, completionPct ?? null, comment ?? null],
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error("Error creating adherence log:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};
