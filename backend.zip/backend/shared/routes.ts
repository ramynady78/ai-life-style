import { z } from "zod";
import {
  upsertUserProfileSchema,
  insertMeasurementSchema,
  type RecommendationContent,
} from "./schema";

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

const dateString = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/, "Expected YYYY-MM-DD");

const recommendationContentSchema: z.ZodType<RecommendationContent> = z.object({
  workout_plan: z.string(),
  daily_routine: z.string(),
  calorie_target: z.number().int().min(800).max(5000),
});

const adjustmentDecisionSchema = z.discriminatedUnion("action", [
  z.object({ action: z.literal("increase_intensity"), reason: z.string() }),
  z.object({ action: z.literal("reduce_difficulty"), reason: z.string() }),
  z.object({ action: z.literal("no_change"), reason: z.string() }),
]);

export const api = {
  health: {
    get: {
      method: "GET" as const,
      path: "/api/health" as const,
      responses: {
        200: z.object({ status: z.literal("ok") }),
      },
    },
  },
  auth: {
    currentUser: {
      method: "GET" as const,
      path: "/api/auth/user" as const,
      responses: {
        200: z.any(),
        401: errorSchemas.unauthorized,
      },
    },
  },
  profile: {
    get: {
      method: "GET" as const,
      path: "/api/profile" as const,
      responses: {
        200: z.object({
          userId: z.string(),
          age: z.number().int().nullable(),
          heightCm: z.number().int().nullable(),
          initialWeightKg: z.number().int().nullable(),
          goalType: z.string().nullable(),
          experienceLevel: z.string().nullable(),
          updatedAt: z.string(),
        }),
        401: errorSchemas.unauthorized,
        404: errorSchemas.notFound,
      },
    },
    upsert: {
      method: "PUT" as const,
      path: "/api/profile" as const,
      input: upsertUserProfileSchema
        .extend({
          age: z.coerce.number().int().min(10).max(120).optional().nullable(),
          heightCm: z.coerce.number().int().min(100).max(250).optional().nullable(),
          initialWeightKg: z.coerce
            .number()
            .int()
            .min(30)
            .max(300)
            .optional()
            .nullable(),
        })
        .partial(),
      responses: {
        200: z.object({
          userId: z.string(),
          age: z.number().int().nullable(),
          heightCm: z.number().int().nullable(),
          initialWeightKg: z.number().int().nullable(),
          goalType: z.string().nullable(),
          experienceLevel: z.string().nullable(),
          updatedAt: z.string(),
        }),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
      },
    },
  },
  recommendation: {
    generatePlan: {
      method: "POST" as const,
      path: "/api/recommendation/generate-plan" as const,
      input: z.undefined().optional(),
      responses: {
        200: z.object({
          plan: recommendationContentSchema,
          version: z.number().int(),
        }),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
        404: errorSchemas.notFound,
      },
    },
    getActive: {
      method: "GET" as const,
      path: "/api/recommendation/active" as const,
      responses: {
        200: z.object({
          id: z.string(),
          userId: z.string(),
          version: z.number().int(),
          status: z.literal("active"),
          content: recommendationContentSchema,
          generatedBy: z.string(),
          createdAt: z.string(),
        }),
        401: errorSchemas.unauthorized,
        404: errorSchemas.notFound,
      },
    },
  },
  tracking: {
    createMeasurement: {
      method: "POST" as const,
      path: "/api/tracking/measurements" as const,
      input: insertMeasurementSchema
        .omit({ id: true, createdAt: true, userId: true, measuredAt: true })
        .extend({
          measuredAt: dateString,
          weightKg: z.coerce.number().int().min(30).max(400).optional().nullable(),
          stepsAvg: z.coerce.number().int().min(0).max(200000).optional().nullable(),
          heartRate: z.coerce.number().int().min(30).max(240).optional().nullable(),
        }),
      responses: {
        201: z.object({
          measurement: z.object({
            id: z.string(),
            userId: z.string(),
            measuredAt: z.string(),
            weightKg: z.number().int().nullable(),
            stepsAvg: z.number().int().nullable(),
            heartRate: z.number().int().nullable(),
            createdAt: z.string(),
          }),
          adjustment: adjustmentDecisionSchema,
        }),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
      },
    },
    listMeasurements: {
      method: "GET" as const,
      path: "/api/tracking/measurements" as const,
      responses: {
        200: z.array(
          z.object({
            id: z.string(),
            userId: z.string(),
            measuredAt: z.string(),
            weightKg: z.number().int().nullable(),
            stepsAvg: z.number().int().nullable(),
            heartRate: z.number().int().nullable(),
            createdAt: z.string(),
          }),
        ),
        401: errorSchemas.unauthorized,
      },
    },
    createAdherenceLog: {
      method: "POST" as const,
      path: "/api/tracking/adherence" as const,
      input: z.object({
        logDate: dateString,
        workoutDone: z.coerce.boolean().optional(),
        completionPct: z.coerce.number().int().min(0).max(100).optional().nullable(),
      }),
      responses: {
        201: z.object({
          id: z.string(),
          userId: z.string(),
          logDate: z.string(),
          workoutDone: z.boolean(),
          completionPct: z.number().int().nullable(),
          createdAt: z.string(),
        }),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
      },
    },
  },
};

export function buildUrl(
  path: string,
  params?: Record<string, string | number>,
): string {
  let url = path;
  if (params) {
    for (const [key, value] of Object.entries(params)) {
      url = url.replace(`:${key}`, String(value));
    }
  }
  return url;
}

export type ProfileResponse = z.infer<typeof api.profile.get.responses[200]>;
export type UpsertProfileInput = z.infer<typeof api.profile.upsert.input>;
export type RecommendationGenerateResponse = z.infer<
  typeof api.recommendation.generatePlan.responses[200]
>;
export type ActiveRecommendationResponse = z.infer<
  typeof api.recommendation.getActive.responses[200]
>;
export type CreateMeasurementInput = z.infer<
  typeof api.tracking.createMeasurement.input
>;
export type CreateMeasurementResponse = z.infer<
  typeof api.tracking.createMeasurement.responses[201]
>;
export type MeasurementsListResponse = z.infer<
  typeof api.tracking.listMeasurements.responses[200]
>;
export type CreateAdherenceLogInput = z.infer<
  typeof api.tracking.createAdherenceLog.input
>;
export type CreateAdherenceLogResponse = z.infer<
  typeof api.tracking.createAdherenceLog.responses[201]
>;
