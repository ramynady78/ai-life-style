import { sql } from "drizzle-orm";
import {
  boolean,
  date,
  index,
  integer,
  jsonb,
  pgEnum,
  pgTable,
  timestamp,
  uniqueIndex,
  uuid,
  varchar,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Replit Auth + optional AI chat integrations (do not remove)
export * from "./models/auth";
export * from "./models/chat";

export const goalTypeEnum = pgEnum("goal_type", [
  "lose_weight",
  "maintain",
  "gain_muscle",
]);

export const experienceLevelEnum = pgEnum("experience_level", [
  "beginner",
  "intermediate",
  "advanced",
]);

export const recommendationStatusEnum = pgEnum("recommendation_status", [
  "active",
  "archived",
]);

export const generatedByEnum = pgEnum("generated_by", ["rule_based", "ai"]);

export const userProfiles = pgTable("user_profile", {
  userId: uuid("user_id").primaryKey(),
  age: integer("age"),
  heightCm: integer("height_cm"),
  initialWeightKg: integer("initial_weight_kg"),
  goalType: goalTypeEnum("goal_type"),
  experienceLevel: experienceLevelEnum("experience_level"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const recommendations = pgTable(
  "recommendations",
  {
    id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
    userId: uuid("user_id").notNull(),
    version: integer("version").notNull(),
    status: recommendationStatusEnum("status").notNull().default("active"),
    content: jsonb("content").notNull(),
    generatedBy: generatedByEnum("generated_by").notNull().default("rule_based"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (t) => [
    uniqueIndex("recommendations_user_version_unique").on(t.userId, t.version),
    index("recommendations_user_status_idx").on(t.userId, t.status),
  ],
);

export const measurements = pgTable("measurements", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").notNull(),
  measuredAt: date("measured_at").notNull(),
  weightKg: integer("weight_kg"),
  stepsAvg: integer("steps_avg"),
  heartRate: integer("heart_rate"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const adherenceLogs = pgTable(
  "adherence_logs",
  {
    id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
    userId: uuid("user_id").notNull(),
    logDate: date("log_date").notNull(),
    workoutDone: boolean("workout_done").notNull().default(false),
    completionPct: integer("completion_pct"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (t) => [uniqueIndex("adherence_logs_user_date_unique").on(t.userId, t.logDate)],
);

export const userProfilesRelations = relations(userProfiles, ({ many }) => ({
  recommendations: many(recommendations),
  measurements: many(measurements),
  adherenceLogs: many(adherenceLogs),
}));

export const recommendationsRelations = relations(recommendations, ({ one }) => ({
  profile: one(userProfiles, {
    fields: [recommendations.userId],
    references: [userProfiles.userId],
  }),
}));

export const measurementsRelations = relations(measurements, ({ one }) => ({
  profile: one(userProfiles, {
    fields: [measurements.userId],
    references: [userProfiles.userId],
  }),
}));

export const adherenceLogsRelations = relations(adherenceLogs, ({ one }) => ({
  profile: one(userProfiles, {
    fields: [adherenceLogs.userId],
    references: [userProfiles.userId],
  }),
}));

export const upsertUserProfileSchema = createInsertSchema(userProfiles).omit({
  updatedAt: true,
});

export const insertMeasurementSchema = createInsertSchema(measurements).omit({
  id: true,
  createdAt: true,
});

export const insertAdherenceLogSchema = createInsertSchema(adherenceLogs).omit({
  id: true,
  createdAt: true,
});

export type UserProfile = typeof userProfiles.$inferSelect;
export type UpsertUserProfileRequest = z.infer<typeof upsertUserProfileSchema>;

export type Measurement = typeof measurements.$inferSelect;
export type CreateMeasurementRequest = z.infer<typeof insertMeasurementSchema>;

export type AdherenceLog = typeof adherenceLogs.$inferSelect;
export type CreateAdherenceLogRequest = z.infer<typeof insertAdherenceLogSchema>;

export type Recommendation = typeof recommendations.$inferSelect;
export type RecommendationContent = {
  workout_plan: string;
  daily_routine: string;
  calorie_target: number;
};

export type RecommendationResponse = Recommendation;

export type AdjustmentDecision =
  | { action: "increase_intensity"; reason: string }
  | { action: "reduce_difficulty"; reason: string }
  | { action: "no_change"; reason: string };
